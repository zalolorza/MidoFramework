<?php

class HomeManager {


	public static function hydrate(&$controller){



	}

}
