<?php
/**
* Running Mido
*
*/


if (class_exists('Mido')){

	Mido::run();

}
