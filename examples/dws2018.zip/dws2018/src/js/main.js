import '../css/main.scss';

import './vendor/events';
import './vendor/scroll_throttle';
import './vendor/browser_detector';

import './components/slider';
import './components/video_background';
import './components/vimeo_popup';
import './components/featured_posts';
import './components/menu';
import './components/google_maps';
import './components/newsletter';





